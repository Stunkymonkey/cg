#pragma once

#include <string>

/// <summary>
/// Main function
/// </summary>
int main(int argc, const char** argv);

/// <summary>
/// Exercises
/// </summary>
void aufgabe1(const std::string& source_file, const std::string& target_file);
void aufgabe2(const std::string& source_file, const std::string& target_file);
void aufgabe3(const std::string& source_file, const std::string& target_file);