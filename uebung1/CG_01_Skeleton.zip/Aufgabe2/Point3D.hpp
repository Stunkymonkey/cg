// CG Assignment 1 Exercise 2 WS 17/18

#ifndef Point3D_hpp
#define Point3D_hpp

struct Point3D
{
	///////
	// TODO
	// Implement the constructor
	Point3D(float x, float y, float z) {}

	///////
	// TODO
	// Implement access to the three coordinate values.
	float x() const {}
	float y() const {}
	float z() const {}

private:
	///////
	// TODO
	// Use a suitable std container to store the three values of a point in 3d space.
	
};

#endif // !Point3D_hpp