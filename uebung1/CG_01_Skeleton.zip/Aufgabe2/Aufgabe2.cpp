// CG Assignment 1 Exercise 2 WS 17/18

#include "Point3D.hpp"
#include "LineStrip3D.hpp"

#include <iostream>


int main()
{

	///////
	// TODO
	// Create a container for linestrips
	

	///////
	// TODO
	// Add three linestrips to the container and add a couple of points to each linestrip
	

	std::cout << "==================================" << std::endl;
	std::cout << "Length of all linestrips:" << std::endl;

	///////
	// TODO
	// Print the length of all line strips on the command line
	

	std::cout << "==================================" << std::endl;
	std::cout << "Length of all linestrips (sorted):" << std::endl;

	///////
	// TODO
	// Sort the line strips in the container based on their length.
	// For validation, print the lengths of all linestrips on the command line one more time.
	
}