// CG Assignment 1 Exercise 2 WS 17/18

#include "LineStrip3D.hpp"


bool LineStrip3D::operator<(LineStrip3D const& rhs)
{
	///////
	// TODO
	// Implement comparison based on length.

}

void LineStrip3D::addPoint(Point3D p)
{
	///////
	// TODO
	// Implement adding a given point to the line strip.
	
}

void LineStrip3D::removePoint(size_t idx)
{
	///////
	// TODO
	// Implement the removal of the point with the given index.
	
}

size_t	LineStrip3D::getPointCount() const
{
	///////
	// TODO
	// Return the number of points of the line strip.
	
}

float LineStrip3D::computeLength() const
{
	///////
	// TODO
	// Implement computation of the line strip's length,
	// that is, the sum of the lengths of all segements.
	
}