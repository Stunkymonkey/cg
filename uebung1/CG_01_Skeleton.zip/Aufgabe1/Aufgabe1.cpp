// CG Assignment 1 Exercise 1 WS 17/18

#include <iostream>

///////
// TODO
// Write a function that computes the circumference of a circle given its radius as input.

int main()
{
	float radius;

	std::cout << "Insert circle radius:" << std::endl;

	///////
	// TODO
	// Get user input from the command line and store it in radius.
	// Check if input is valid.
	
	///////
	// TODO
	// Call the function circumference and output the computed value to the command line.
	
}