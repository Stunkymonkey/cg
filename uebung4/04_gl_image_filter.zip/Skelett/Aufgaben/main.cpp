#include "ImageViewer.h"

int main(const int argc, const char** argv)
{
	std::cout << "Uni Stuttgart - CG Exercise 4 - WS17/18" << std::endl;

	cg::ImageViewer image_viewer;
	image_viewer.run();

	return 0;
}