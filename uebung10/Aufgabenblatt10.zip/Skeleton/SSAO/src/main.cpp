#include "renderer.hpp"

int main()
{
	cg::SSAO_Renderer renderer;
	return renderer.Run();
}